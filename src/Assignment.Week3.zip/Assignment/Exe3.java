package Assignment;

public class Exe3 {
public static void main(String [] args) {
	int num1 =2;
	int square = num1*num1;
	System.out.println("The required square is " +square);
    
	int cube =  num1*num1*num1;
	System.out.println("The required cube is " +cube);

	int fourth = (int) Math.pow(num1, 4);
	System.out.println("The required fourth power is " +fourth);

	
}
}
