package Assignment;
public class Exe2 {

	public static void main(String[] args) {
		double num1 = 8.5;
		int num2 = 11;
		System.out.println("l="+num1 +"," +"b="+num2);
			double dbl1 = 2*(num1+num2);
			System.out.println("The Required Perimeter is " +dbl1 +" inch");
 double dbl2 =Math.pow(num1, 2);
 double dbl3 = Math.pow(num2,2);
 
double dbl4 = dbl2+dbl3;
float dbl5 = (float) Math.sqrt(dbl4);


System.out.println("The required length of a Diagonal is " +dbl5 +" inch");
			
			
			
			
	}

}
