package Assignment;

public class Exe12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str1 = "+--+--+--+";
		String str2 = "|  |  |  |";
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str1);
	}

}
