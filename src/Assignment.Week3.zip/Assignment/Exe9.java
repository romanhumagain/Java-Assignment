package Assignment;
import java.util.*;
public class Exe9 {

	public static void main(String[] args) {
		
Scanner sc = new Scanner(System.in);
System.out.print("Enter the Drive Letter: ");
 String str1 =sc.next();


System.out.print("Enter The Path: ");		
String str2 =sc.next();

System.out.print("Enter the file name: ");
String str3 =sc.next();

System.out.print("Enter the extension:  ");
String str4 =sc.next();



System.out.println(str1+""+str2+""+str3+""+str4);
}

}
