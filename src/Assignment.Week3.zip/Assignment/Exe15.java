package Assignment;

public class Exe15 {
public static void main(String[] args) {
String H = "*   *\n*   *\n*****\n*   *\n*   *\n ";
System.out.println(H);
String E = "****\n*\n****\n*\n**** \n";
System.out.println(E);
String L = "*\n*\n*\n****\n ";
System.out.println(L);
String l = "*\n*\n*\n****\n ";
System.out.println(l);
String O = "   *\n *   *\n *   *\n   *\n";
System.out.println(O);

}
}
